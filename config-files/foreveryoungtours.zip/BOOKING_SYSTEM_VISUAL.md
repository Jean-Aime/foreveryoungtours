# 📊 Booking System Visual Guide

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    CUSTOMER BOOKING OPTIONS                      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │  Which option?  │
                    └────────┬────────┘
                             │
              ┌──────────────┴──────────────┐
              ▼                             ▼
    ┌──────────────────┐          ┌──────────────────┐
    │  QUICK BOOKING   │          │ CUSTOM INQUIRY   │
    │  (Specific Tour) │          │ (Custom Planning)│
    └────────┬─────────┘          └────────┬─────────┘
             │                              │
             ▼                              ▼
    ┌──────────────────┐          ┌──────────────────┐
    │ tour-booking.php │          │ booking-form.php │
    │  (Single Page)   │          │   (5 Steps)      │
    └────────┬─────────┘          └────────┬─────────┘
             │                              │
             ▼                              ▼
    ┌──────────────────┐          ┌──────────────────┐
    │process-booking.php│         │submit-booking.php│
    └────────┬─────────┘          └────────┬─────────┘
             │                              │
             ▼                              ▼
    ┌──────────────────┐          ┌──────────────────┐
    │ bookings table   │          │booking_inquiries │
    │  BK2025XXXX      │          │    INQ-XXX       │
    └────────┬─────────┘          └────────┬─────────┘
             │                              │
             └──────────────┬───────────────┘
                            ▼
                  ┌──────────────────┐
                  │  ADMIN PANEL     │
                  │ (Shows Both)     │
                  └──────────────────┘
```

---

## Form Comparison

### 🚀 Quick Booking Form

```
┌─────────────────────────────────────────┐
│         QUICK TOUR BOOKING              │
├─────────────────────────────────────────┤
│                                         │
│  📋 Customer Information                │
│  ├─ Full Name                          │
│  ├─ Email                              │
│  ├─ Phone                              │
│  └─ Emergency Contact                  │
│                                         │
│  📅 Travel Details                      │
│  ├─ Travel Date (specific)             │
│  ├─ Participants (1-50)                │
│  ├─ Accommodation (Standard/Premium)   │
│  └─ Transport (Shared/Private)         │
│                                         │
│  💳 Payment Method                      │
│  ├─ Credit Card                        │
│  ├─ PayPal                             │
│  └─ Bank Transfer                      │
│                                         │
│  💰 Price Summary                       │
│  ├─ Base: $1,500                       │
│  ├─ Upgrades: $350                     │
│  └─ Total: $1,850                      │
│                                         │
│  [  Complete Booking  ]                │
│                                         │
└─────────────────────────────────────────┘
```

### 📋 Custom Inquiry Form

```
┌─────────────────────────────────────────┐
│       CUSTOM TOUR INQUIRY               │
├─────────────────────────────────────────┤
│                                         │
│  Step 1: Traveler Details               │
│  ├─ Name, Email, Phone                 │
│  ├─ Adults & Children                  │
│  ├─ Travel Dates (flexible text)       │
│  └─ Budget Range                       │
│                                         │
│  Step 2: Tour Preferences               │
│  ├─ Categories (multiple)              │
│  ├─ Destinations (multiple)            │
│  └─ Activities (multiple)              │
│                                         │
│  Step 3: Group Information              │
│  ├─ Group Type                         │
│  ├─ Group Size                         │
│  └─ Group Leader                       │
│                                         │
│  Step 4: Travel Details                 │
│  ├─ Flight Preferences                 │
│  ├─ Hotel Preferences                  │
│  └─ Additional Services                │
│                                         │
│  Step 5: Review & Submit                │
│  ├─ Referral Source                    │
│  ├─ Special Requests                   │
│  └─ Notes                              │
│                                         │
│  [  Submit Inquiry  ]                  │
│                                         │
└─────────────────────────────────────────┘
```

---

## User Journey

### Quick Booking Journey

```
Customer sees tour
       ↓
Clicks "Book Now"
       ↓
Lands on tour-booking.php
(Pre-filled with tour info)
       ↓
Fills single-page form
       ↓
Sees real-time price updates
       ↓
Submits booking
       ↓
Gets booking reference: BK20250123
       ↓
Receives confirmation email
       ↓
Admin sees in bookings list
```

### Custom Inquiry Journey

```
Customer wants custom tour
       ↓
Clicks "Plan Custom Tour"
       ↓
Lands on booking-form.php
       ↓
Step 1: Basic info
       ↓
Step 2: Preferences
       ↓
Step 3: Group details
       ↓
Step 4: Travel details
       ↓
Step 5: Review & submit
       ↓
Gets inquiry reference: INQ-45
       ↓
Receives acknowledgment email
       ↓
Admin reviews & creates quote
       ↓
Customer receives custom itinerary
```

---

## Admin Panel View

```
┌────────────────────────────────────────────────────────────────┐
│                      BOOKING MANAGEMENT                         │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Statistics:                                                    │
│  ┌──────────┬──────────┬──────────┬──────────┬──────────┐    │
│  │  Total   │ Confirmed│ Pending  │ Revenue  │Commission│    │
│  │   156    │    89    │   45     │ $234,500 │ $23,450  │    │
│  └──────────┴──────────┴──────────┴──────────┴──────────┘    │
│                                                                 │
│  Recent Bookings:                                              │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │ Ref         │ Customer    │ Tour          │ Status      │ │
│  ├──────────────────────────────────────────────────────────┤ │
│  │ BK20250123  │ John Doe    │ Safari Tour   │ ✅ Confirmed│ │
│  │ INQ-45 🔵   │ Jane Smith  │ Custom Tour   │ ⏳ Pending  │ │
│  │ BK20250122  │ Bob Wilson  │ Beach Tour    │ ✅ Confirmed│ │
│  │ INQ-44 🔵   │ Alice Brown │ Group Safari  │ ⏳ Pending  │ │
│  │ BK20250121  │ Tom Davis   │ City Tour     │ 💰 Paid     │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
│  🔵 = Inquiry Badge                                            │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

---

## Database Structure

### bookings Table (Quick Bookings)

```
┌─────────────────────────────────────────┐
│ id: 123                                 │
│ booking_reference: BK20250123           │
│ tour_id: 5                              │
│ customer_name: John Doe                 │
│ customer_email: john@email.com          │
│ customer_phone: +1234567890             │
│ travel_date: 2025-06-15                 │
│ participants: 2                         │
│ accommodation_type: premium             │
│ transport_type: private                 │
│ total_amount: 3500.00                   │
│ payment_method: credit_card             │
│ status: confirmed                       │
│ payment_status: paid                    │
└─────────────────────────────────────────┘
```

### booking_inquiries Table (Custom Inquiries)

```
┌─────────────────────────────────────────┐
│ id: 45                                  │
│ tour_id: NULL                           │
│ tour_name: Custom Safari                │
│ client_name: Jane Smith                 │
│ email: jane@email.com                   │
│ phone: +1234567890                      │
│ travel_dates: "June-July 2025"          │
│ adults: 4                               │
│ budget: "$10,000-$15,000"               │
│ categories: "Safari, Culture"           │
│ destinations: "Kenya, Tanzania"         │
│ activities: "Wildlife, Photography"     │
│ group_type: "Family"                    │
│ status: pending                         │
└─────────────────────────────────────────┘
```

---

## Price Calculation Flow

### Quick Booking

```
Base Price (from tour)
       ↓
    $1,500
       ↓
× Participants (2)
       ↓
    $3,000
       ↓
+ Accommodation Upgrade
  (Premium: $100 × 2)
       ↓
    $3,200
       ↓
+ Transport Upgrade
  (Private: $150 × 2)
       ↓
    $3,500
       ↓
= TOTAL: $3,500
```

### Custom Inquiry

```
Customer provides budget range
       ↓
    "$10,000-$15,000"
       ↓
Admin reviews requirements
       ↓
Creates custom quote
       ↓
Sends detailed itinerary
       ↓
Customer approves
       ↓
Converts to confirmed booking
```

---

## Status Workflow

```
┌─────────────┐
│   PENDING   │ ← Initial status
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  CONFIRMED  │ ← Admin confirms
└──────┬──────┘
       │
       ▼
┌─────────────┐
│    PAID     │ ← Payment received
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  COMPLETED  │ ← Tour finished
└─────────────┘
```

---

## Integration Points

```
┌─────────────────────────────────────────────────────────────┐
│                      WEBSITE PAGES                           │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   Homepage   │    │  Tour Pages  │    │  Navigation  │
└──────┬───────┘    └──────┬───────┘    └──────┬───────┘
       │                   │                    │
       │ "Book Now"        │ "Book This Tour"   │ "Booking"
       │                   │                    │
       └───────────────────┼────────────────────┘
                           ▼
                ┌──────────────────┐
                │ booking-options  │
                │      .php        │
                └────────┬─────────┘
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
    ┌──────────────────┐  ┌──────────────────┐
    │ tour-booking.php │  │ booking-form.php │
    └──────────────────┘  └──────────────────┘
```

---

## Success Metrics

```
┌─────────────────────────────────────────┐
│         BOOKING METRICS                 │
├─────────────────────────────────────────┤
│                                         │
│  Quick Bookings:                        │
│  ████████████████░░░░ 80%              │
│  (Fast checkout, high conversion)       │
│                                         │
│  Custom Inquiries:                      │
│  ████░░░░░░░░░░░░░░░ 20%              │
│  (Higher value, more planning)          │
│                                         │
│  Average Values:                        │
│  • Quick Booking: $2,500               │
│  • Custom Inquiry: $8,500              │
│                                         │
│  Conversion Rates:                      │
│  • Quick Booking: 65%                  │
│  • Custom Inquiry: 45%                 │
│                                         │
└─────────────────────────────────────────┘
```

---

**Visual guide complete! Use this for training and reference.** 📊
