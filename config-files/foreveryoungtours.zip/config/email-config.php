<?php
// Email Configuration
// IMPORTANT: Update these with your actual Gmail credentials

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'baraime450@gmail.com'); // Change this to your Gmail
define('SMTP_PASSWORD', 'kkxlbpvarhuqndun');     // Gmail App Password (no spaces)
define('SMTP_FROM_EMAIL', 'noreply@iForYoungTours.com');
define('SMTP_FROM_NAME', 'iForYoungTours');

// HOW TO GET GMAIL APP PASSWORD:
// 1. Go to https://myaccount.google.com/security
// 2. Enable 2-Step Verification
// 3. Go to https://myaccount.google.com/apppasswords
// 4. Create new app password for "Mail"
// 5. Copy the 16-character password and paste above
?>
