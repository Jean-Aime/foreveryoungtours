<?php
// Redirect to auth/login.php
header('Location: auth/login.php');
exit();
?>